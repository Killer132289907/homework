<?php include 'includes/header.php'; ?>
<div class="container my-5">
    <h1>Технологии и инструменты</h1>
    <p>Мы используем передовое программное обеспечение и оборудование для создания визуальных эффектов мирового уровня.</p>
    <div class="row mt-4">
        <div class="col-md-3 text-center">
            <img src="company/images/11.jpg" alt="Houdini" class="img-fluid" style="max-height:80px;">
            <h5>Houdini</h5>
            <p>Процедурная генерация и симуляции</p>
        </div>
        <!-- добавить другие -->
    </div>
</div>
<?php include 'includes/footer.php'; ?>
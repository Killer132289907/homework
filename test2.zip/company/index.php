<?php include 'includes/header.php'; ?>

<!-- Hero секция -->
<section class="hero text-center">
    <div class="container">
        <h1 class="display-3 fw-bold">Создаём невозможное</h1>
        <p class="lead">Профессиональные визуальные эффекты для кино, рекламы и digital-контента</p>
        
        <a href="company/portfolio.php" class="btn btn-primary btn-lg mt-3">Смотреть работы</a>
    </div>
</section>

<!-- О компании кратко -->
<section class="container my-5">
    <h2 class="section-title">VFX Studio — магия в каждом кадре</h2>
    <div class="row align-items-center">
        <div class="col-md-6">
            <p>Мы команда профессионалов, влюблённых в создание визуальных эффектов. С 2015 года помогаем режиссёрам, продюсерам и брендам воплощать самые смелые идеи. Используем передовые технологии и индивидуальный подход к каждому проекту.</p>
            <a href="company/about.php" class="btn btn-outline-primary">Подробнее о нас</a>
        </div>
        <div class="col-md-6">
            <img src="company/images/vfx.png" alt="Команда VFX Studio" class="img-fluid rounded">
        </div>
    </div>
</section>

<!-- Услуги -->
<section class="bg-light py-5">
    <div class="container">
        <h2 class="section-title">Наши услуги</h2>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 service-card">
                    <img src="company/images/1.png" class="card-img-top" alt="CGI и 3D-графика">
                    <div class="card-body">
                        <h5 class="card-title">CGI и 3D-графика</h5>
                        <p class="card-text">Фотореалистичная 3D-графика, анимация, моделирование окружения и персонажей.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 service-card">
                    <img src="company/images/2.jpg" class="card-img-top" alt="Композитинг">
                    <div class="card-body">
                        <h5 class="card-title">Композитинг</h5>
                        <p class="card-text">Бесшовное объединение отснятого материала с компьютерной графикой, цветокоррекция.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 service-card">
                    <img src="company/images/3.jpg" class="card-img-top" alt="Motion Design">
                    <div class="card-body">
                        <h5 class="card-title">Motion Design</h5>
                        <p class="card-text">Анимированная графика, титры, инфографика для рекламы и презентаций.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-4">
            <a href="company/services.php" class="btn btn-primary">Все услуги</a>
        </div>
    </div>
</section>

<!-- Последние проекты -->
<section class="container my-5">
    <h2 class="section-title">Избранные проекты</h2>
    <div class="row g-3">
        <div class="col-md-4">
            <div class="portfolio-item">
                <p class="mt-2 fw-bold">1.Фантастический фильм "Грани"</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="portfolio-item">
                <p class="mt-2 fw-bold">2.Реклама бренда "Velocity"</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="portfolio-item">
                <p class="mt-2 fw-bold">3.Музыкальный клип "Neon Nights"</p>
            </div>
        </div>
    </div>
    <div class="text-center mt-4">
        <a href="company/portfolio.php" class="btn btn-outline-primary">Всё портфолио</a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
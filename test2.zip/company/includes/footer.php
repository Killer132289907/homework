</main>
<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <p>&copy; 2026 VFX Studio. Все права защищены.</p>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="#" class="text-white me-3">Политика конфиденциальности</a>
                <a href="#" class="text-white">Условия использования</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap JS (локальный) -->
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
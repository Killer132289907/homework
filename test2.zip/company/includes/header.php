<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Профессиональная студия визуальных эффектов для кино, рекламы и видеороликов. Создаём впечатляющие спецэффекты любой сложности.">
    <meta name="keywords" content="VFX, спецэффекты, визуальные эффекты, CGI, композитинг, 3D-графика, видеомонтаж, постпродакшн">
    <meta name="author" content="VFX Studio">
    <base href="/">
    <title>VFX Studio — профессиональные спецэффекты</title>
    <!-- Bootstrap CSS (локальный) -->
    <link rel="stylesheet" href="company/css/bootstrap.min.css">
    <!-- Пользовательские стили -->
    <link rel="stylesheet" href="company/css/style.css">
    <!-- Favicon (опционально) -->
    <link rel="icon" type="company/images/logo.png" href="company/images/logo.png">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container">
        <a class="navbar-brand" href="company/index.php">
            <img src="company/images/logo.png" alt="VFX" height="40">
        </a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="company/index.php">Главная</a></li>
                <li class="nav-item"><a class="nav-link" href="company/about.php">О нас</a></li>
                <li class="nav-item"><a class="nav-link" href="company/services.php">Услуги</a></li>
                <li class="nav-item"><a class="nav-link" href="company/portfolio.php">Портфолио</a></li>
                <li class="nav-item"><a class="nav-link" href="company/technology.php">Технологии</a></li>
                <li class="nav-item"><a class="nav-link" href="company/contact.php">Контакты</a></li>
            </ul>
        </div>
    </div>
</nav>
<main>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем данные из формы
    $name = strip_tags(trim($_POST["name"]));
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $phone = isset($_POST["phone"]) ? strip_tags(trim($_POST["phone"])) : 'не указан';
    $message = strip_tags(trim($_POST["message"]));
    
    // Проверяем заполнение обязательных полей
    if (empty($name) || empty($message) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Редирект с ошибкой (можно обработать детальнее)
        header("Location: ../contact.php?success=0");
        exit;
    }
    
    // Формируем строку для записи
    $date = date("Y-m-d H:i:s");
    $ip = $_SERVER['REMOTE_ADDR'];
    $entry = "Дата: $date | IP: $ip | Имя: $name | Email: $email | Телефон: $phone | Сообщение: $message" . PHP_EOL;
    
    // Путь к файлу (лежит в той же папке php или лучше вне корня, но для простоты в php)
    $file = __DIR__ . '/contacts.txt';
    
    // Записываем в файл
    file_put_contents($file, $entry, FILE_APPEND | LOCK_EX);
    
    // Редирект обратно на страницу контактов с параметром успеха
    header("Location: ../contact.php?success=1");
    exit;
} else {
    // Если не POST, возвращаем на контакты
    header("Location: ../contact.php");
    exit;
}
?>
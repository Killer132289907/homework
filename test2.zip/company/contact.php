<?php include 'includes/header.php'; ?>

<div class="container my-5">
    <h1 class="mb-4">Свяжитесь с нами</h1>
    <div class="row">
        <div class="col-md-6">
            <h4>Контакты</h4>
            <p><strong>Адрес:</strong> г. Москва, ул. Примерная, д. 123, офис 45</p>
            <p><strong>Телефон:</strong> +7 (999) 123-45-67</p>
            <p><strong>Email:</strong> info@vfxstudio.ru</p>
            <p><strong>Режим работы:</strong> Пн-Пт 10:00–19:00</p>
            <div class="mt-4">
                <iframe src="https://yandex.ru/map-widget/v1/?ll=37.617700%2C55.755800&z=12" width="100%" height="300" frameborder="0"></iframe>
            </div>
        </div>
        <div class="col-md-6">
            <div class="contact-form">
                <h4>Оставьте заявку</h4>
                <form action="company/php/save_contact.php" method="post">
                    <div class="mb-3">
                        <label for="name" class="form-label">Ваше имя *</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email *</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">Телефон</label>
                        <input type="tel" class="form-control" id="phone" name="phone">
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Сообщение *</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Отправить</button>
                </form>
                <?php
                // Вывод сообщения об успешной отправке (если есть параметр в URL)
                if (isset($_GET['success']) && $_GET['success'] == 1) {
                    echo '<div class="alert alert-success mt-3">Спасибо! Ваше сообщение отправлено.</div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
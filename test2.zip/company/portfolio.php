<?php include 'includes/header.php'; ?>

<div class="container my-5">
    <h1 class="mb-4">Наши работы</h1>
    <p class="lead">Мы гордимся каждым проектом, в который вложили частицу мастерства и вдохновения. Здесь представлены избранные работы для кино, рекламы и музыкальной индустрии.</p>

    <!-- Фильтры (декоративные, без JS) -->

    <!-- Галерея проектов -->
    <div class="row g-4">
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm">
                <img src="company/images/5.jpg" class="card-img-top" alt="Фантастический фильм 'Грани'">
                <div class="card-body">
                    <h5 class="card-title">Фильм «Грани»</h5>
                    <p class="card-text text-muted">Кино • 2025</p>
                    <p class="card-text">Создание цифровых двойников актёров, разрушение зданий, атмосферные эффекты. Более 200 шотов с полным циклом VFX.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm">
                <img src="company/images/6.jpg" class="card-img-top" alt="Реклама бренда Velocity">
                <div class="card-body">
                    <h5 class="card-title">Velocity Sport</h5>
                    <p class="card-text text-muted">Реклама • 2026</p>
                    <p class="card-text">Динамичная интеграция 3D-графики в живые съёмки. Анимированные логотипы и симуляции частиц для спортивного бренда.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm">
                <img src="company/images/7.jpg" class="card-img-top" alt="Клип Neon Nights">
                <div class="card-body">
                    <h5 class="card-title">Neon Nights</h5>
                    <p class="card-text text-muted">Музыкальный клип • 2024</p>
                    <p class="card-text">Киберпанк-эстетика: неоновые отражения, голографические проекции, цифровая ретушь и композитинг в стиле sci-fi.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm">
                <img src="company/images/8.jpg" class="card-img-top" alt="Сериал Эон">
                <div class="card-body">
                    <h5 class="card-title">Сериал «Эон»</h5>
                    <p class="card-text text-muted">Кино • 2023</p>
                    <p class="card-text">Визуальные эффекты для исторического фэнтези: магические способности, окружение, цифровые существа.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm">
                <img src="company/images/images.png" class="card-img-top" alt="Реклама автомобиля Aura">
                <div class="card-body">
                    <h5 class="card-title">Aura Motors</h5>
                    <p class="card-text text-muted">Реклама • 2025</p>
                    <p class="card-text">Полностью CGI-ролик: создание окружения, фотореалистичная модель автомобиля, динамические отражения.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-4">
            <div class="card h-100 border-0 shadow-sm">
                <img src="company/images/10.jpg" class="card-img-top" alt="Короткометражный фильм Пульс">
                <div class="card-body">
                    <h5 class="card-title">К/м «Пульс»</h5>
                    <p class="card-text text-muted">Кино • 2024</p>
                    <p class="card-text">Экспериментальный проект с акцентом на абстрактные визуальные эффекты и генеративный арт.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Призыв к действию -->
    <div class="text-center mt-5 p-4 bg-light rounded">
        <h3>Готовы обсудить ваш проект?</h3>
        <p class="mb-3">Расскажите нам о своей идее, и мы предложим лучшее визуальное решение.</p>
        <a href="company/contact.php" class="btn btn-primary btn-lg">Связаться с нами</a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
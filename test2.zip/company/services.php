<?php include 'includes/header.php'; ?>
<div class="container my-5">
    <h1 class="mb-4">Наши услуги</h1>
    <div class="row g-4">
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title">CGI / 3D</h5>
                    <p class="card-text">Моделирование, текстурирование, анимация, симуляции (жидкости, ткань, частицы), рендеринг фотореалистичных сцен.</p>
                </div>
            </div>
        </div>
        <!-- Добавить ещё услуги -->
    </div>
</div>
<?php include 'includes/footer.php'; ?>